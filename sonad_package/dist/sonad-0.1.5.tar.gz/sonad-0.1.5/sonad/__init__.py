"""
SOftware NAme Disambiguation tool
SOftware NAme Disambiguation: A tool for disambiguating software names and their URLs in scientific literature.
"""

__version__ = "0.1.0"
__author__ = "Jelena Duric"
__email__ = "djuricjelena611@gmail.com"
